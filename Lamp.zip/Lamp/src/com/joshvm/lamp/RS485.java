package com.joshvm.lamp;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.microedition.io.Connector;
import javax.microedition.io.StreamConnection;

public class RS485 {
	private static String com = "COM3";
	// 波特率
	private static int baudrate = 9600;

	private static StreamConnection streamConnection;
	private static InputStream inputStream;
	private static OutputStream outputStream;

	public static void set_light(byte[] msg) {
		System.out.println("Start RS485 Connection...");

		String host = "comm:" + com + ";baudrate=" + baudrate + ";parity=even";
		
		try {

			// 建立连接
			streamConnection = (StreamConnection) Connector.open(host);
//			inputStream = streamConnection.openInputStream();
			outputStream = streamConnection.openOutputStream();
			
			System.out.println("Get ready to set light");
			outputStream.write(msg);
			for (int i = 0; i < msg.length; i++) {
				System.out.print(msg[i] + " ");
			}
			outputStream.flush();
//			System.out.println("\n" + new String(msg));
			System.out.println("Lamp's lightness is turned");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				outputStream.close();
//				inputStream.close();
				streamConnection.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

}
