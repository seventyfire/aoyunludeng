package com.joshvm.lamp;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
//import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import com.joshvm.lamp.Subscriber;
import com.joshvm.lamp.Utils;

public class Lamp {
	private static MqttClient mqttClient;
	// broker URL
	private static String url = "tcp://127.0.0.1:1883";
	private static String user = "mybroker";
	private static String passwd = "123456";
	
		
		
	public static void main(String[] args) {
		
		System.out.println("Start Mqtt Client...");
		
		try {
			// 建立连接，ClientId为唯一标识
			mqttClient = new MqttClient(url, Utils.getImei(), new MemoryPersistence());
			MqttConnectOptions options = new MqttConnectOptions();
			options.setCleanSession(true);
			options.setUserName(user);
			options.setPassword(passwd.toCharArray());
			mqttClient.connect(options);
			System.out.println("connected!");
			
//			CellularDeviceInfo[] devices = CellularDeviceInfo.listCellularDevices();
			
			// 订阅
			System.out.println("subscribed!");
			Subscriber.subscribe(mqttClient);
		    //使当前线程无限等待
//		    while (true) {
//		    	Thread.sleep(2000);
//		    }
//			// 发布
//			Date date = new Date();
//			// 获取网络信号
//			int sl = devices[0].getNetworkSignalLevel();
//			Publisher.push(mqttClient, "date: " + date.toString() + ", Signal Strength(0~31):" + sl);
		    
			
		} catch (Exception e) {
			e.printStackTrace();
		}
//		} finally {
//			try {
//				mqttClient.close();
//			} catch (MqttException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
	}
}
