package com.joshvm.lamp;
//import java.io.InputStream;
//import java.io.OutputStream;

//import javax.microedition.io.StreamConnection;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class Subscriber {
	private static final String SET_LIGHT = "josh/set_light";
	
	public static void subscribe(MqttClient mqttClient) {

		try {
			mqttClient.subscribe(SET_LIGHT, 1);
			
			mqttClient.setCallback(new MqttCallback() {

				public void messageArrived(String topic, MqttMessage arg1) throws Exception {

//					System.out.println("Client topic: " + topic);
//					System.out.println("Client qos: " + arg1.getQos());
//					System.out.println("Client payload: " + new String(arg1.getPayload()));
					byte[] data = Utils.getMessage(new String(arg1.getPayload()));
					if (SET_LIGHT.equals(topic)){
						 // 即时调光命令(亮度0、色温0)->(33 33), "98"循环冗余校验码，需要重新计算
						String str = "68 73 66 21 00 00 00 68 04 04 58 F4 33 33 98 16";
						
						byte[] msg = Utils.getMessage(str);
						
						
//						System.out.println(new String(Utils.getMessage("68 73 66 21 00 00 00 68 04 04 58 F4 3D 3D 98 16")));
						msg[12] += data[0];
						msg[13] += data[1];
						msg[14] = Utils.checkCS(msg, msg.length - 2);
						RS485.set_light(msg);
//						for (int i = 0; i < msg.length; i++) {
//							String tString = Integer.toBinaryString((msg[i] & 0xFF) + 0x100).substring(1);
//							System.out.print(tString + " ");
//						}
//						System.out.println();
						
					} else {
						System.out.println("No function found!");
					}
					
					
				}

				public void deliveryComplete(IMqttDeliveryToken arg0) {
					System.out.println("Client topic: " + arg0);
				}

				public void connectionLost(Throwable arg0) {
					System.out.println("Client topic: " + arg0);
				}
			});

		} catch (MqttException e) {
			e.printStackTrace();
		}
	}
}
