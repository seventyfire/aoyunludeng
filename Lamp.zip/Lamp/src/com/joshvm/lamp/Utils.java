package com.joshvm.lamp;
import java.io.IOException;

import org.joshvm.j2me.cellular.CellularDeviceInfo;

public class Utils {
	
	/**
	 * 获取设备IMEI
	 * @return
	 */
	public static String getImei() {

		String imei = "";

		CellularDeviceInfo[] devices = CellularDeviceInfo.listCellularDevices();
		if (devices != null && devices.length > 0) {

			try {
				imei = devices[0].getIMEI();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return imei;
	}
	
	public static byte[] getMessage(String str){
//		String raw = "68 73 66 21 00 00 00 68 04 04 58 F4 97 97 4C 16";
		byte[] message = new byte[(str.length() - 2) / 3 + 1];
		int j = 0;
		int i = 2;
        for (; i <= str.length(); i += 3){
        	message[j++] = (byte) (Integer.parseInt(str.substring(i - 2, i),16) & 0xff);
        }
//        message[j++] = (byte) (Integer.parseInt(str.substring(i - 2, i),16) & 0xff);

        return message;
	}
	

    // CS和校验
    public static byte checkCS(byte[] byteArr, int len)
    {
        byte result = 0;

        int num = 0;
        for (int i = 0; i < len; i++)
        {
            num = (num + byteArr[i]) % 256;
        }
        result = (byte)num;
        

        return result;
    }

}