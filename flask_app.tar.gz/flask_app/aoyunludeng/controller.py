import os
from flask import Flask
from flask import render_template
from program import Program
from flask import request, flash, redirect, url_for
from werkzeug.utils import secure_filename
from flask_cors import CORS, cross_origin
UPLOAD_FOLDER = './ZipInput'
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'mp4', 'mov', 'wmv', 'avi'}

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
app.config['SECRET_KEY'] = 'secert key'
CORS(app)

@app.route('/')
def root():
    return render_template('index.html')


@app.route('/send_program', methods=['GET', 'POST'])
def send_program():
    json_data = request.args.get('json_data')
    print("======>>>json_data" + json_data)
    program = Program(json_data)
    prog_name = program.send_program()
    print("send program:" + prog_name)
    return {"program_name": prog_name}

@cross_origin()
@app.route('/play_program', methods=['GET', 'POST'])
def play_program():
    program_name = request.args.get('program_name')
    program = Program()
    program.play_program(program_name)
    return "200"

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/to_upload', methods=['GET', 'POST'])
def upload_file():
    print("upload.......")
    if request.method == 'POST':
        print(request.files)
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['file']
        # if user does not select file, brower also submit an empty part without filename
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        print("\n\n"+str(file.filename)+"\n\n")
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            print("\n\n2"+str(file.filename)+"\n\n")
            return redirect(url_for('upload_file', filename = filename))

    return '''
    <!doctype html>
    <title>Upload new File</title>
    <h1>Upload new File</h1>
    <form method=post enctype=multipart/form-data>
      <input type=file name=file>
      <input type=submit value=Upload>
    </form>
    '''

@app.route('/multiple_upload', methods=['GET', 'POST'])
def upload_files():
    if request.method == 'POST':
        if 'file[]' not in request.files:
            flash('No file part')
            return redirect(request.url)
        files = request.files.getlist("file[]")
        # if user does not select file, brower also submit an empty part without filename
        for file in files:
            print(file)
            if file.filename == '':
                flash('No selected file')
                return redirect(request.url)
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        return redirect(url_for('upload_file', filename = filename))

    return '''
    <!doctype html>
    <title>Upload Multiple File</title>
    <h1>Upload Multiple File</h1>
    <form method="post" enctype="multipart/form-data">
      <input type="file" name="file[]" multiple="">
      <input type="submit" value="add">
    </form>
    '''


@app.route('/clear')
def clear_resources():
    program = Program()
    program.clear_resources()
    return "200"


#@app.route('/uploads/<filename>')
#def uploaded_file(filename):
#    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)


if __name__ == "__main__":
    app.run(host='0.0.0.0')
